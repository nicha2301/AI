package Lab1.agent_ABCD;

public abstract class Action {
    public abstract boolean isNoOp();
}
