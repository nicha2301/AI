package Lab1.agent_ABCD;

public class Agent {
    private AgentProgram program;

    public Agent() {
    }

    public Agent(AgentProgram aProgram) {
        program = aProgram;
    }

    public Action execute(Percept p) {
        if (program != null) {
            return program.execute(p);
        }
        return NoOpAction.NO_OP;
    }
}